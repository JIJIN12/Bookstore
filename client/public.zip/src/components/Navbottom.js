import React from 'react'
import './Nav.css'
import bootstrap from 'bootstrap'
export default function Navbottom() {

  return (
    <div>
      <div className=''>
        <nav className='bottom_navbar'>
          <a href='/' className='fas fa-home'></a>
          <p className='fas fa-list dropdown navbottom_p'  ></p>

          


          <a href='' className='fas fa-tags'></a>
          <a href='' className='fas fa-comments'></a>
          <a href='' className='fas fa-blogs'></a>
        </nav>
      </div>
    </div>
  )
}
