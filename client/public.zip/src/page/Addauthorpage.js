import React from 'react'
import Navtop from '../components/Navtop'
import Addauthor from '../components/Addauthor'
import Navbottom from '../components/Navbottom'

export default function Addauthorpage() {
  return (
    <div>
      <Navtop/>
      <Addauthor/>
      <Navbottom/>
    </div>
  )
}
