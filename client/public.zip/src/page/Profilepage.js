import React from 'react'
import Navtop from '../components/Navtop'
import Profle from '../components/Profle'
import Navbottom from '../components/Navbottom'

export default function Profilepage() {
  return (
    <div>
      <Navtop/>
      <Profle/>
      <Navbottom/>
    </div>
  )
}
