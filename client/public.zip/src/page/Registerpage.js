import React from 'react'
import Navtop from '../components/Navtop'
import Register from '../components/Register'
import Navbottom from '../components/Navbottom'

export default function Registerpage() {
  return (
    <div>
      <Navtop/>
      <Register/>
      <Navbottom/>
    </div>
  )
}
